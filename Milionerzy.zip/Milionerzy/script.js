const correct = new Audio("correct.wav");
const wrong = new Audio("wrong.wav");
const clap = new Audio("clap.wav");

const pytania = [
    {
        pytanie: "W którym roku wybuchła rewolucja francuska?",
        odpowiedzA: "1543",
        odpowiedzB: "1678",
        odpowiedzC: "1789",
        odpowiedzD: "1818",
        dobra: "C"
    },
    {
        pytanie: "Ile lat miał najstarszy człowiek świata?",
        odpowiedzA: "116 lat",
        odpowiedzB: "122 lata",
        odpowiedzC: "125 lat",
        odpowiedzD: "128 lat",
        dobra: "B"
    },
    {
        pytanie: "Na akord można:",
        odpowiedzA: "spać",
        odpowiedzB: "pracować",
        odpowiedzC: "śpiewać",
        odpowiedzD: "podróżować",
        dobra: "B"
    },
    {
        pytanie: "Co oznaczają stringi w programowaniu?",
        odpowiedzA: "ciągi znaków",
        odpowiedzB: "liczby",
        odpowiedzC: "wartości prawda - fałsz",
        odpowiedzD: "funkcje",
        dobra: "A"
    },
    {
        pytanie: " Jak nazywa się postać, którą gramy w grze Hollow Knight? ",
        odpowiedzA: " the Hollow Knight ",
        odpowiedzB: " the Knight ",
        odpowiedzC: " Hornet ",
        odpowiedzD: " Quirell ",
        dobra: "B"
    },
    {
        pytanie: " Jak jest 'słowo' po hiszpańsku? ",
        odpowiedzA: " word ",
        odpowiedzB: " la parole ",
        odpowiedzC: " la parola ",
        odpowiedzD: " la palabra ",
        dobra: "D"
    },
    {
        pytanie: " Kto napisał książkę 'All the Bright Places'? ",
        odpowiedzA: " Jennifer Niven ",
        odpowiedzB: " Art Hobson ",
        odpowiedzC: " Michael Thomas Ford ",
        odpowiedzD: " Oliver Bowden ",
        dobra: "A"
    },
    {
        pytanie: " Na jakiej asteroidzie mieszkał Mały Książę? ",
        odpowiedzA: " B-512 ",
        odpowiedzB: " B-516 ",
        odpowiedzC: " B-612 ",
        odpowiedzD: " B-616 ",
        dobra: "C"
    },
    {
        pytanie: " W XIX wieku brytyjscy uczeni zwrócili uwagę na to, że na terenie kolonii w południowo-wschodniej Azji ludzie bez żadnego wyraźnego powodu zaczęli tracić czucie w stopach. Jak potocznie nazywano tę przypadłość? ",
        odpowiedzA: " Szkorbut ",
        odpowiedzB: " Beri-beri ",
        odpowiedzC: " Osteoporoza ",
        odpowiedzD: " Przypadłość Christiego ",
        dobra: "B"
    },
    {
        pytanie: " Ile około procent wszechświata tworzy zwykła materia? ",
        odpowiedzA: " 5% ",
        odpowiedzB: " 20% ",
        odpowiedzC: " 50% ",
        odpowiedzD: " 80% ",
        dobra: "A"
    },
    {
        pytanie: " Ile płytek na jednej ściance ma Pyraminx? ",
        odpowiedzA: " 6 ",
        odpowiedzB: " 7 ",
        odpowiedzC: " 8 ",
        odpowiedzD: " 9 ",
        dobra: "D"
    },
    {
        pytanie: " Jak nazywa się firma produkująca butelki z filtrem? ",
        odpowiedzA: " Tefal ",
        odpowiedzB: " Arifa ",
        odpowiedzC: " Dafi ",
        odpowiedzD: " Vinde ",
        dobra: "C"
    },
    {
        pytanie: "Kto napisał mangę Attack on Titan?",
        odpowiedzA: "Machiko Hasegawa",
        odpowiedzB: "Hajime Isayama",
        odpowiedzC: "Rumiko Takahashi",
        odpowiedzD: "Naoko Takeuchi",
        dobra: "B"
    }
]

let count = 0;
let currentCorrectAnswer;
let money = 13;
let blokada = true;
const abcd = ['A', 'B', 'C', 'D'];

const loadNewQuestion = () => {
    const questionNumber = Math.floor(Math.random() * pytania.length);

    document.getElementById("question").innerHTML = pytania[questionNumber].pytanie;
    document.getElementById("questionA").innerHTML = "A: " + pytania[questionNumber].odpowiedzA;
    document.getElementById("questionB").innerHTML = "B: " + pytania[questionNumber].odpowiedzB;
    document.getElementById("questionC").innerHTML = "C: " + pytania[questionNumber].odpowiedzC;
    document.getElementById("questionD").innerHTML = "D: " + pytania[questionNumber].odpowiedzD;
    currentCorrectAnswer = pytania[questionNumber].dobra;

    [pytania[pytania.length - 1], pytania[questionNumber]] = [pytania[questionNumber], pytania[pytania.length - 1]];
    pytania.pop();
}

loadNewQuestion();

const yellow = (litera) => {
    if (blokada) {

        ok();

        blokada = false;

        abcd.forEach(elem => {
            document.getElementById("question" + elem).classList.remove("answer2");
        })

        const div = "question" + litera;

        document.getElementById(div).classList.add("zolty");

        setTimeout(function () {
            document.getElementById(div).classList.remove("zolty");

            odp(litera);
        }, 1500);
    }
}

const odp = (litera) => {
    const div = "question" + litera;

    if (litera === currentCorrectAnswer) {
        correct.play();
        document.getElementById(div).classList.add("zielony");
        setTimeout('dobraOdp()', 2000);
    }
    else {
        wrong.play();
        document.getElementById(div).style.background = "rgba(154, 46, 46, 0.9)";
        setTimeout('naKoniec()', 2000);
        setTimeout('zlaOdp()', 5000);
    }
}

const naKoniec = () => {
    document.getElementById("question" + currentCorrectAnswer).classList.add("zielony");
}

const dobraOdp = () => {
    money--;
    if (money > 0) {
        const div = "monet" + money
        let div2;
        if (money < 12) div2 = "monet" + (money + 1);
        document.getElementById(div).style.background = "rgba(119, 224, 250, 0.40)";
        if (money < 12) document.getElementById(div2).style.background = "rgba(119, 224, 250, 0.12)";
    }
    else {
        clap.play();
        document.getElementById("questions").innerHTML = "<div id='ded' style='cursor:pointer;' onclick='refresh()'>Wygrałeś 1 000 000 złotych!</div>"
        return true;
    };
    count++;
    loadNewQuestion();

    abcd.forEach(elem => {
        document.getElementById("question" + elem).classList.remove("zielony");
        document.getElementById("question" + elem).classList.add("answer2");
        document.getElementById("question" + elem).setAttribute("onclick", "yellow('" + elem + "')");
    })
    blokada = true;
}

const zlaOdp = () => {

    if (count === 0) {
        document.getElementById("questions").innerHTML = "<div id='ded' style='cursor:pointer;' onclick='refresh()'>Wygrałeś 0 złotych :(</div>"
    }
    else {
        const div = "monet" + money
        const ile = document.getElementById(div).innerHTML.replace(" ", "")
        if (ile < 1000) document.getElementById("questions").innerHTML = "<div id='ded' style='cursor:pointer;' onclick='refresh()'>Wygrałeś 0 złotych :(</div>"
        else if (ile < 40000) document.getElementById("questions").innerHTML = "<div id='ded' style='cursor:pointer;' onclick='refresh()'>Wygrałeś 1000 złotych!</div>"
        else document.getElementById("questions").innerHTML = "<div id='ded' style='cursor:pointer;' onclick='refresh()'>Wygrałeś 40 000 złotych!</div>"
    }
}

const refresh = () => {
    location.reload()
};

const fifty = () => {
    if (blokada) {
        document.getElementById('pol').removeAttribute("onclick");
        document.getElementById('pol').classList.remove("kolo2");
        const litery = ['A', 'B', 'C', 'D'];
        const reszta = [];
        for (let index = 0; index < litery.length; index++) {
            if (litery[index] !== currentCorrectAnswer)
                reszta.push(litery[index]);
        }
        let div;
        const reszta2 = [];
        const other = reszta[Math.floor(Math.random() * reszta.length)];
        for (let index = 0; index < reszta.length; index++) {
            if (reszta[index] !== other)
                reszta2.push(reszta[index]);
        }
        reszta2.forEach(element => {
            div = document.getElementById("question" + element);
            div.innerHTML = "";
            div.removeAttribute("onclick");
            div.classList.remove("answer2");
        });
    }
}

const telefon = () => {
    if (blokada) {
        document.getElementById("okienkoTelefon").style.opacity = "100%";
        document.getElementById('telefon').classList.remove("kolo2");
        document.getElementById('telefon').removeAttribute("onclick");
        let odpT;
        if (Math.round(Math.random(0, 1) * 10, 1) > 2) {
            odpT = currentCorrectAnswer;
        }
        else {
            const litery = ['A', 'B', 'C', 'D'];
            const reszta = [];
            for (let index = 0; index < litery.length; index++) {
                if (litery[index] !== currentCorrectAnswer)
                    reszta.push(litery[index]);
            }
            odpT = reszta[Math.round(Math.random(0, 1) * 10, 1) % 3]
        }
        document.getElementById("okienkoTelefon").innerHTML = "<div>Wiesz, nie jestem na 100% pewien, ale myślę, że to może być odpowiedź " + odpT + "</div>";
    }

}

const ok = () => {
    document.getElementById("okienkoTelefon").style.opacity = "0";
    document.getElementById("okienkoTelefon").innerHTML = "";
}

const publicznosc = () => {
    if (blokada) {
        document.getElementById("okienkoTelefon").style.opacity = "100%";
        document.getElementById('publicznosc').classList.remove("kolo2");
        document.getElementById('publicznosc').removeAttribute("onclick");
        document.getElementById("okienkoTelefon").innerHTML = "<div><div><div id='odpA'></div><div id='odpB'></div><div id='odpC'></div><div id='odpD'></div></div></div>";
        document.getElementById("odpA").innerHTML = "A: ";
        document.getElementById("odpB").innerHTML = "B: ";
        document.getElementById("odpC").innerHTML = "C: ";
        document.getElementById("odpD").innerHTML = "D: ";

        let oA = Math.round(Math.random(0, 1) * 50, 1);
        for (let i = 0; i < oA; i++) {
            document.getElementById("odpA").innerHTML += "|";
        }
        let oB = Math.round(Math.random(0, 1) * (50 - oA), 1);
        for (let i = 0; i < oB; i++) {
            document.getElementById("odpB").innerHTML += "|";
        }
        let oC = Math.round(Math.random(0, 1) * (50 - oA - oB), 1);
        for (let i = 0; i < oC; i++) {
            document.getElementById("odpC").innerHTML += "|";
        }
        let oD = Math.round(Math.random(0, 1) * (50 - oA - oB - oC), 1);
        for (let i = 0; i < oD; i++) {
            document.getElementById("odpD").innerHTML += "|";
        }

        const wymien = "odp" + currentCorrectAnswer;
        document.getElementById(wymien).innerHTML += "||||||||||||||||||||||||||||||||||||||||||||||||||";
    }
}

const quit = () => {
    let ile = 0;
    if (count != 0) ile = document.getElementById("monet" + money).innerHTML;
    document.getElementById("questions").innerHTML = "<div id='ded' style='cursor:pointer;' onclick='refresh()'>Wygrałeś " + ile + " złotych!</div>";
    document.getElementById("quitButton").style.opacity = "0";
    document.getElementById("quitButton").style.cursor = "default";
}