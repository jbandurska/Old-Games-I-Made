var haslo1 = "";
var alfabet = "AĄBCĆDEĘFGHIJKLŁMNŃOÓPQRSŚTUVWXYZŹŻ";
var bylyZ = "";
var bylyD = "";
var dal = alfabet.length;
var haslo = "";
var yes = new Audio("yes.wav");
var no = new Audio("no.wav");
var win = new Audio("win.wav");
var lose = new Audio("lose.wav");

function wypisz_haslo()
{
    haslo = document.getElementById("pobierz").value;
    if (haslo!="")
    {
        haslo = haslo.toUpperCase();
    dlugosc = haslo.length;
    for (i = 0; i < dlugosc; i++)
    {
        if (haslo.charAt(i) == " " || haslo.charAt(i) == "," || haslo.charAt(i) == "-") haslo1 += haslo.charAt(i)
        else haslo1 += "_"
    }
    document.getElementById("plansza").innerHTML = haslo1;
    document.getElementById("pobierz").value = "";
    document.getElementById("haslo").innerHTML = "";
    }
}

var licznik = 0

function litera(litera)
{
    if (haslo != "")
    {
        // dobra litera
        if (haslo.includes(litera))
        {
            yes.play();
            var haslo2 = ""
            for (i = 0; i < dlugosc; i++)
            {
                if (haslo.charAt(i) == litera) haslo2 += litera
                else haslo2 += haslo1[i]
            }
            document.getElementById("plansza").innerHTML = haslo2
            bylyD += litera
            haslo1 = haslo2;
        }
        // zła litera
        else
        {
            no.play();
            if (licznik <= 8)
            {
                if (!(bylyZ.includes(litera))) licznik += 1;
                document.getElementById("szubienica").innerHTML = "<img src=\"img/s" + licznik + ".jpg\">"
                bylyZ += litera
            }
            // lose
            if (licznik > 8)
            {
                lose.play();
                document.getElementById("alfabet").innerHTML = "<p class=\"paragraf1\">Przegrałeś</p><p onclick=\"od_nowa();\" style=\"cursor: pointer;font-weight: bold;\">Spróbuj ponownie</p>"
                document.getElementById("plansza").innerHTML = haslo
            }
        }
        if (licznik <= 8)
        {
            alfabe();
        }
        // win
        if (haslo == haslo1 && haslo != "")
        { 
            document.getElementById("alfabet").innerHTML = "<p class=\"paragraf1\">Wygrałeś! Gratulacje!</p><p onclick=\"od_nowa();\" style=\"cursor: pointer;font-weight: bold;\">Zagraj jeszcze raz</p>";
            win.play(); 
        }
    }
}

function od_nowa()
{
    window.location.reload();
}
function alfabe()
{
    document.getElementById("alfabet").innerHTML = ""
    for (j = 0; j < dal; j++)
    {
        letter = alfabet.charAt(j)
        if (bylyD.includes(letter))
        {
            document.getElementById("alfabet").innerHTML += "<div class=\"litera\" style=\"margin: 0 0 8px 10px;color:rgb(0, 180, 0);border-color:rgb(0, 180, 0);background-color:#002200;\" onclick=\"litera('" + letter + "');\">" + letter + "</div>"
        }
        else if (bylyZ.includes(letter))
        {
            document.getElementById("alfabet").innerHTML += "<div class=\"litera\" style=\"margin: 0 0 8px 10px;color:rgb(180, 0, 0);border-color:rgb(180, 0, 0);background-color: #220000;\" onclick=\"litera('" + letter + "');\">" + letter + "</div>"
        }
        else 
        {
            document.getElementById("alfabet").innerHTML += "<div class=\"litera white\" style=\"margin: 0 0 8px 10px;\" onclick=\"litera('" + letter + "');\">" + letter + "</div>"
        }
    }
}
window.onload = alfabe;
